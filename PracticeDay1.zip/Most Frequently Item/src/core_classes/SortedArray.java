package core_classes;

import java.util.ArrayList;
import java.util.Arrays;

public class SortedArray {
public static void main(String []args) {
	int i,j;
	int count=0;
	int []intArray= {1,3,4,6,7,9};
	int[]intArray1= {1,2,4,5,9,10};
	
	//int found=0;
	
	ArrayList<Integer> commonElement = new ArrayList<Integer>();
	for(i=0;i<intArray.length;i++) {
		
		for(j=0;j<intArray1.length;j++) {
			if (intArray[i]==intArray1[j]) {
				//found=intArray[i];
				//System.out.println(found+" ");
				commonElement.add(intArray[i]);
			}	
		}
	}
	System.out.println(commonElement);
	
	

}
}