package core_classes;

import java.util.HashMap;

public class SortedArrayUsingMap {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		
	}

}
