package core_classes;
public class Item {
	public static void main(String[] args) {
		
		//Scanner sc = new Scanner(System.in);
		int count=0;
		int i,j;
		int temp=0;
		int element=0;
		
		//int size=sc.nextInt();
		int [] intArray = {3,3,1,3,2,1,3};
		
		for(i=0;i<intArray.length-1;i++)
		{
			//System.out.println("in for(i)");
			for(j=i+1;j<intArray.length;j++ )
			{
				//System.out.println("in for(j)");
				if(intArray[i]==intArray[j])
				{
					count++;
				}
				
			}
			//System.out.println(count);
			//System.out.println("outside for(j)");
			if(count>temp)
			{
				temp=count;
				count = 0;
				element=intArray[i];
			}
			
		}
		//System.out.println("out for(i)");
		System.out.println("Found Element: " +element+"  Count: "+temp);
		
		
	}
	
}
