package core_classes;

import java.util.Scanner;
//import static java.lang.Math;


public class Strings {

	public static void main(String[] args) {
		
		Scanner sc = new Scanner(System.in);
		
		int count=0;
		
		System.out.println("Enter string 1: ");
		String s1=sc.next();
		System.out.println("Enter string 2: ");
		String s2=sc.next();
	
		if(s1.length()==s2.length() || (s1.length()>s2.length()) || (s2.length()>s1.length()))
		{
			if(s1.length()==s2.length())
			{
				for(int i=0;i<s1.length();i++)
				{
					if(s1.charAt(i)!=s2.charAt(i))
					{
						count++;
					}
				}
				if(count>1)
				{
					System.out.println("Not ONE AWAY....");
				}
				else
					System.out.println("ONE AWAY....");
			}
			
			else if(s1.length()>s2.length())
			{
				for(int i=0;i<s2.length();i++)
				{
					if(s1.charAt(i)!=s2.charAt(i))
					{
						count++;
					}
				}
				if(count>1)
				{
					System.out.println("Not ONE AWAY....");
				}
				else
					System.out.println("ONE AWAY....");
			}
			
			else if(s2.length()>s1.length())
			{
				for(int i=0;i<s1.length();i++)
				{
					if(s1.charAt(i)!=s2.charAt(i))
					{
						count++;
					}
				}
				if(count>1)
				{
					System.out.println("Not ONE AWAY....");
				}
				else
					System.out.println("ONE AWAY....");
			}
			else
				System.out.println("ONE AWAY....");
		}
	}

}
