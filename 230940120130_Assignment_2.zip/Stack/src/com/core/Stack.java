package com.core;

import java.util.Scanner;

public class Stack extends RuntimeException {
	private int top,element;
	private int[] stack;
	
	public Stack()
	{
		top=-1;
		stack=new int[5];
	}
	
	boolean IsEmpty () {
		return top==-1;
	}
	boolean IsFull(){
		return top==stack.length-1;
		
	}
	
	public void push(int element)throws  RuntimeException  {
		if(IsFull()) {
			throw new RuntimeException("stack is full");
		}
		else
		{
			top=top+1;
			stack[top]=element;
			//System.out.println("Top in Push :"+top);
		}
	}
	
	public int pop() throws RuntimeException  {
			if(IsEmpty())
			{
				throw new RuntimeException(" Stack is Empty");
			}
			else
				element=stack[top];
				stack[top]=0;
			    //System.out.println("Top Before Pop :"+top);
				top=top-1;
				//System.out.println("Top in Pop :"+top);
				return element;
			
	}
		public int peek() {
			if(IsEmpty()) 
			{
				System.out.println(" Stack is Empty");
				return 0;
			}
			else
				return stack[top];
		}
		public void display() {
			for(int st:stack )
			{
				System.out.println(st);
			}
		}

		
}
