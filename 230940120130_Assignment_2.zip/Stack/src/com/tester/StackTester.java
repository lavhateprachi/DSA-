package com.tester;

import java.util.Scanner;

import com.core.Stack;

public class StackTester {

	public static void main(String[]args) throws RuntimeException  {
		Scanner sc=new Scanner(System.in);
		Stack s = new Stack();
		boolean exit=false;
		while(!exit) {
				System.out.println("Options: ");
				System.out.println("1. push ");
				System.out.println("2. pop ");
				System.out.println("3. peek ");
				System.out.println("4. Display ");
				System.out.println("5.Exit");
				System.out.println();
				
				System.out.println("Enter Choice: ");
				switch(sc.nextInt())
				{
				case 1:
					
					System.out.println("Enter Element: ");
					s.push(sc.nextInt());
					System.out.println("Element Pushed Into Stack.....");
					break;
					
					
				case 2:
					
					System.out.println(s.pop());
					System.out.println("Element Deleted from stack....");
					break;
					
				case 3:
					System.out.println("Peek Element: ");
					System.out.println(s.peek());
					break;
					
				case 4:
					System.out.println("Number Of Elements: ");

					System.out.println("display all element");
					s.display();
					break;
					
				case 5:
					exit=true;
					break;
				}
	
		}
	
}

}
