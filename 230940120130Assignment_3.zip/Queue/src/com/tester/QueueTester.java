package com.tester;

import java.util.Scanner;

import com.core.Queue;

public class QueueTester {

	public static void main(String[]args){
		try(Scanner sc=new Scanner(System.in);)
		{
			
			
			System.out.println("Enter Size of Queue: ");
			Queue queue = new Queue(sc.nextInt());
			boolean exit=false;
			while(!exit) {
					System.out.println("Options: ");
					System.out.println("1. Enqueue ");
					System.out.println("2. Dequeue ");
					System.out.println("3. Display ");
					System.out.println("4.Exit");
					System.out.println();
					
					System.out.println("Enter Choice: ");
					
					try {
					        switch(sc.nextInt())
					
							{
									case 1:
										
										System.out.println("Enter Element: ");
										queue.enqueue(sc.nextInt());
										System.out.println("Element Pushed Into Queue.....");
										break;
										
									case 2:
										
										System.out.println(queue.dequeue());
										System.out.println("Element Deleted from Queue....");
										break;
										
									case 3:
										System.out.println("Display all element");
										queue.display();
										break;
										
									case 4:
										exit=true;
										break;
							}
							
					}
					catch(Exception e)
					{
						e.printStackTrace();
					}
		
			  }
		
	      }
			
	}
		
}
