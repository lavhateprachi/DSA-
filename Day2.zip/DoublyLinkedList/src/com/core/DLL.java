package com.core;

public class DLL {
	private Node head;
	private Node tail;


	public DLL() {
		super();
		this.head = null;
		this.tail=null;
	}

	public static class Node {
		int data;
		Node next;
		Node prev;

		public Node(int data) {
			super();
			this.data = data;
			this.next = null;
			this.prev=null;
		}

	}

	public void display() {
		Node trav = head;
		while (trav != null) {
			System.out.print(trav.data + "->");
			trav = trav.next;
		}
	}

	public void addAtFirst(int data) {
		Node node = new Node(data);
		if (head == null)
		{
			head = node;
			tail=node;
		}
		else 
		{
			node.next = head;
			node.prev=null;
			head = node;
		}
	}

	public void addAtLast(int data) {

		Node newNode = new Node(data);
		if (head == null)
		{
			head = newNode;
			tail=newNode;
		}
		tail.next=newNode;
		newNode.prev=tail;
		tail=newNode;
		tail.next=null;
		
	}

//	public void addAtMid(int data, int pos) {
//
//		Node newNode = new Node(data);
//		Node trav = head;
//		if (head == null) {
//			head = newNode;
//		}
//		for (int i = 0; i < pos; i++)
//			trav = trav.next;
//		newNode.next = trav.next;
//		trav.next = newNode;
//	}
//
//	public int delAtFirst() {
//		if (head == null)
//			throw new RuntimeException("linkedList is Empty");
//		else {
//			int element = head.data;
//			head = head.next;
//			return element;
//		}
//	}
//
//	public int delAtLast() {
//		
//		Node prev=null;
//		if (head == null)
//			throw new RuntimeException("linkedList is Empty");
//		else {
//			Node trav = head;
//			while (trav.next != null) {
//				prev=trav; 
//				trav = trav.next;	
//			}
//			int element = trav.data;
//			prev.next=null;
//			return element;
//		}
//	}
//
//	public int delAtMid(int position) {
//		if (position == 0)
//			return delAtFirst();
//
//		Node trav = head;
//		Node prev = null;
//		for (int i = 0; i < position; i++) {
//			prev=trav;0
//			trav = trav.next;
//		}
//		System.out.println(trav.data);
//		int data = trav.data;
//		prev.next=trav.next;
//		return data;
//	}
//
//	public void delAll() {
//		head = null;
//	}

}
