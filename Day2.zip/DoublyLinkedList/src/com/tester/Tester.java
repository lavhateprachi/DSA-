package com.tester;
import com.core.*;
public class Tester {
	public static void main(String[] args) {
		DLL list=new DLL();
		list.addAtFirst(10);
		list.addAtFirst(20);
		list.addAtFirst(30);
		list.addAtLast(45);
		list.display();
	}

}
