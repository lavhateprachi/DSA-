package com.core;

public class Queue {
	private int rear,front,element;
	private int[] queue;
	
	public Queue(int size)
	{
		rear=-1;
		front=-1;
		queue=new int[size];
	}
	
	boolean isFull()
	{
		if(rear==queue.length-1)
		{
			return true;
		}
		else
		{
			return false;
		}
	}
	boolean isEmpty()
	{
		if(front==-1)
		{
			return true;
		}
		else 
			return false;
	}
	public void enqueue(int element)
	{
		if(isFull())
		{
			throw new RuntimeException("Queue is Full.....");
			//System.out.println("Queue Is Fulll....");
		}
		else
		{
			if(front==-1)
			{
				front=0;
			}
			rear=rear+1;
			queue[rear]=element;
		}
	}
	
	public int dequeue() {
		if(isEmpty())
		{
			throw new RuntimeException("Queue is EMPTY.....");
			//System.out.println("Queue Is EMPTY....");
		}
		element=queue[front];
		queue[front]=0;
		front=front+1;
		return element;
		
	}
	public void display() {
		for(int st:queue )
		{
			System.out.println(st);
		}
	}
	

}
