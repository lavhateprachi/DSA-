package com.core;

public class CircularQueue {
	private int rear,front,element;
	private int[] queue;
	
	public CircularQueue(int size)
	{
		rear=-1;
		front=-1;
		queue=new int[size];
	}
	
	boolean isFull()
	{
		if(front==0 && rear==queue.length-1)
		{
			return true;
		}
		else
		{
			return false;
		}
	}
	boolean isEmpty()
	{
		if(front==-1)
		{
			return true;
		}
		else 
			return false;
	}
	public void enqueue(int element)
	{
		if(isFull())
		{
			throw new RuntimeException("Queue is Full.....");
		}
		else
		{
			if(front==-1)
			{
				front=0;
			}
			rear=(rear+1)%queue.length;
			queue[rear]=element;
		}
	}
	
	public int dequeue() {
		if(isEmpty())
		{
			throw new RuntimeException("Queue is EMPTY.....");
		}
		element=queue[front];
		front=(front+1)%queue.length;
		return element;
		
	}
	public void display() {
		for(int st:queue )
		{
			System.out.println(st);
		}
	}
	

}



